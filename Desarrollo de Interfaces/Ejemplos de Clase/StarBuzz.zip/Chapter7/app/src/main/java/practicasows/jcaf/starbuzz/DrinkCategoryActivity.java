package practicasows.jcaf.starbuzz;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class DrinkCategoryActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_drink_category);
    }
}
