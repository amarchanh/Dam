package seconddam.com.a06_intent_explicito;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }

    public void iniciarActivity(View view) {
        //Escribiremos el código necesario para iniciar el
        //activity DatosActivity >>>> intent explicito

        EditText nameText=(EditText)findViewById(R.id.name);
        String nameString = nameText.getText().toString();
        EditText ageText=(EditText)findViewById(R.id.age);
        String ageString = ageText.getText().toString();

        Intent intentDatos = new Intent(this, DatosActivity.class);
        //intentDatos.putExtra("numero",nameString);
        //intentDatos.putExtra("nombre", ageString);
        intentDatos.putExtra(DatosActivity.name,nameString);
        intentDatos.putExtra(DatosActivity.edad,ageString);
        startActivity(intentDatos);
    }
}
