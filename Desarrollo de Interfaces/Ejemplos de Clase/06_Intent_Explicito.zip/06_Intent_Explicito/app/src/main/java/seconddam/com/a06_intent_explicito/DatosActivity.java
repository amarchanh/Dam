package seconddam.com.a06_intent_explicito;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.widget.TextView;

public class DatosActivity extends AppCompatActivity {

    final static String name="name";
    final static String edad="edad";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_datos);

        //Bundle extras = getIntent().getExtras();

        //String edad = extras.getString("numero");
        //String nombre = extras.getString("nombre");

        Intent intent = getIntent();
        String nameText = intent.getStringExtra(name);
        String ageText = intent.getStringExtra(edad);

        TextView textView = (TextView)findViewById(R.id.textVactivity2);
        //textView.setText("Me llamo "+nombre+"\nMi edad es:"+edad);
        textView.setText("Me llamo:"+nameText+"\n"+"Mi edad es:"+ageText);


    }
}
