package hfad.jcaf.workout;


import android.os.Bundle;

import androidx.fragment.app.Fragment;

import android.os.Handler;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;

import java.util.Locale;


/**
 * A simple {@link Fragment} subclass.
 */
public class StopwatchFragment extends Fragment implements View.OnClickListener {

    //Numero de segundos que se muestran en el reloj
    private int seconds = 0;

    //Control si el reloj esta parado o en movimiento
    private boolean running;
    private boolean wasRunning;

    //Recuperamos los valores anteriores del reloj
    public void onCreate(Bundle savedInstanceState){
        super.onCreate(savedInstanceState);
        if(savedInstanceState!=null){
            seconds=savedInstanceState.getInt("seconds");
            running=savedInstanceState.getBoolean("running");
            wasRunning=savedInstanceState.getBoolean("wasRunning");
        }
    }


    public StopwatchFragment() {
        // Required empty public constructor
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        //Seteamos el layout del fragment para poderlo usar
        View layout=inflater.inflate(R.layout.fragment_stopwatch, container, false);
        runTimer(layout);

        Button startButton = (Button)layout.findViewById(R.id.start_button);
        startButton.setOnClickListener(this);
        Button stopButton = (Button)layout.findViewById(R.id.stop_button);
        stopButton.setOnClickListener(this);
        Button resetButton = (Button)layout.findViewById(R.id.reset_button);
        resetButton.setOnClickListener(this);
        return layout;
    }

    public void onClick(View v){
        switch(v.getId()){
            case(R.id.start_button):
                onClickStart();
                break;
            case(R.id.stop_button):
                onClickStop();
                break;
            case(R.id.reset_button):
                onClickReset();
                break;
        }
    }

    public void onPause(){
        super.onPause();
        wasRunning=running;
        running=false;
    }

    public void onResume(){
        super.onResume();
        if(wasRunning){
            running=true;
        }
    }

    //Metodo para arrancar el reloj, cuando se pulsa Start
    private void onClickStart(){
        running=true;
    }
    //Metodo para parar el reloj
    private void onClickStop(){
        running=false;
    }
    //Metodo para resetear el reloj
    private void onClickReset(){
        running=false;
        seconds=0;
    }

    //Sobreescribimos el metodo para guardar los datos
    public void onSaveInstanceState(Bundle savedInstanceState){
        savedInstanceState.putInt("seconds",seconds);
        savedInstanceState.putBoolean("running",running);
        savedInstanceState.putBoolean("wasRunning", wasRunning);
    }

    //Metodo que se lanza a segundo plano para mostrar el reloj en pantalla

    private void runTimer(View view){
        final TextView timeView = (TextView)view.findViewById(R.id.time_view);
        final Handler handler = new Handler();
        handler.post(new Runnable() {
            @Override
            public void run() {
                int hours = seconds/3600;
                int minutes=(seconds%3600)/60;
                int secs=seconds%60;
                String time = String.format(Locale.getDefault(),
                        "%d:%02d:%02d", hours, minutes,secs);
                timeView.setText(time);
                if(running){
                    seconds++;
                }
                handler.postDelayed(this,1000);
            }
        });
    }



}
