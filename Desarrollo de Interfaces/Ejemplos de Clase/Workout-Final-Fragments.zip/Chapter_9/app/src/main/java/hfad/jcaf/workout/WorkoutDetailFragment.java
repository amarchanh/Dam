package hfad.jcaf.workout;


import android.os.Bundle;

import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentTransaction;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;


/**
 * A simple {@link Fragment} subclass.
 */
public class WorkoutDetailFragment extends Fragment {

    public void onCreate(Bundle savedInstanceState){
        super.onCreate(savedInstanceState);

        if(savedInstanceState==null){
            StopwatchFragment stopwatchFragment = new StopwatchFragment();
            FragmentTransaction fragmentTransaction = getChildFragmentManager().beginTransaction();
            fragmentTransaction.add(R.id.stopwatch_container,stopwatchFragment);
            fragmentTransaction.setTransition(FragmentTransaction.TRANSIT_FRAGMENT_FADE);
            fragmentTransaction.commit();
        }
        else{

            workoutId=savedInstanceState.getLong("workoutId");
        }

    }

    private long workoutId;
    //El ID del workout que el usuario elegirá más adelante


    public WorkoutDetailFragment() {
        // Required empty public constructor
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        return inflater.inflate(R.layout.fragment_workout_detail, container, false);
    }

    @Override
    public void onStart() {
        super.onStart();
        //Llamada al metodo onStart padre
        View view = getView();
        //Esta linea devuelve el fragment raiz
        if(view!=null){
            TextView title = (TextView)view.findViewById(R.id.textTitle);
            //Fragment no incluye el metodo findViewById
            //Para usarlo necesitamos primero usar una referencia al fragment padre
            Workout workout = Workout.workouts[(int) workoutId];
            title.setText(workout.getName());
            TextView description = (TextView)view.findViewById(R.id.textDescription);
            description.setText((workout.getDescription()));
        }
    }

    public void setWorkoutId(long id){
        //metodo setter que usara la activity para pasar el ID
        this.workoutId=id;
    }

    public void onSaveInstanceState(Bundle savedInstanceState){

        savedInstanceState.putLong("workoutId", workoutId);
    }









}
