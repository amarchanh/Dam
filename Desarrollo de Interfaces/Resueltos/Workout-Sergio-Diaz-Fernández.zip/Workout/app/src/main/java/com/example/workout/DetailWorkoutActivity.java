package com.example.workout;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.TextView;

public class DetailWorkoutActivity extends AppCompatActivity {

    public static final String EXTRA_EXERCISE_ID = "genericId";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_detail_workout);

        TextView textView = (TextView)findViewById(R.id.name);
        TextView textView2 = (TextView)findViewById(R.id.description);

        //Acceder al elemento del array que queremos mostrar.
        int iD = (Integer)getIntent().getExtras().get(EXTRA_EXERCISE_ID);

        //Rellenamos los elementos visuales
        Exercise exercise = Exercise.exercises[iD];
        textView.setText(exercise.getName());
        textView2.setText(exercise.getDescription());
    }
}
