package com.example.practice3;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.Spinner;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }

    public void onClickEnviar(View view){

        EditText titulo = (EditText)findViewById(R.id.editText_titulo);
        String tituloString = titulo.getText().toString();

        EditText autor = (EditText)findViewById(R.id.editText_autor);
        String autorString = autor.getText().toString();

        EditText ano = (EditText)findViewById(R.id.editText_ano);
        String anoString = ano.getText().toString();

        Spinner spinner = (Spinner)findViewById(R.id.spinner_genero);
        String option_selected = String.valueOf(spinner.getSelectedItem());

        boolean checked;
        CheckBox checkBox = (CheckBox) findViewById(R.id.checkBox_noticias);
        checked = checkBox.isChecked();


        Intent intentDatos = new Intent(this, AgregarLibro.class);
        intentDatos.putExtra("titulo",tituloString);
        intentDatos.putExtra("autor", autorString);
        intentDatos.putExtra("ano", anoString);
        intentDatos.putExtra("genero", option_selected);
        intentDatos.putExtra("noticias", checked);
        startActivity(intentDatos);
    }
}
