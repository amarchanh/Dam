package com.hfad.bibliolectura;


import android.content.Intent;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v7.widget.GridLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;


/**
 * A simple {@link Fragment} subclass.
 */
public class ScienceFFragment extends Fragment {


    public ScienceFFragment() {
        // Required empty public constructor
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {

        RecyclerView sciencefRecycler = (RecyclerView)inflater.inflate(
                R.layout.fragment_sciencef,container,false);

        String[] sciencefNames = new String[ScienceF.sciences.length];
        for(int i=0; i<sciencefNames.length;i++){
            sciencefNames[i]= ScienceF.sciences[i].getName();
        }
        int[] sciencefImages= new int[ScienceF.sciences.length];
        for(int i=0; i<sciencefImages.length;i++){
            sciencefImages[i]= ScienceF.sciences[i].getImageResourceId();
        }

        CaptionedImagesAdapter adapter = new CaptionedImagesAdapter(sciencefNames, sciencefImages);
        sciencefRecycler.setAdapter(adapter);
        GridLayoutManager layoutManager = new GridLayoutManager(getActivity(),2);
        sciencefRecycler.setLayoutManager(layoutManager);

        adapter.setListener(new CaptionedImagesAdapter.Listener() {
            @Override
            public void onClick(int position) {
                Intent intent = new Intent(getActivity(), ScienceFDetailActivity.class);
                intent.putExtra(ScienceFDetailActivity.EXTRA_SCIENCEF_ID,position);
                getActivity().startActivity(intent);
            }
        });

        return sciencefRecycler;

    }

}
