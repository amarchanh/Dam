package com.hfad.bibliolectura;

public class Horror {

    private String name;
    private int imageResourceId;
    private String plot;

    public static final Horror[] horrors ={
            new Horror("Dracula", R.drawable.dracula, "The tale begins with Jonathan Harker, a newly qualified English solicitor, visiting Count Dracula at his castle in the Carpathian Mountains on the border of Transylvania, Bukovina, and Moldavia, to provide legal support for a real estate transaction overseen by Harker's employer, Mr Peter Hawkins of Exeter. Initially impressed by Dracula's gracious manners, Harker soon realizes that he is Dracula's prisoner. Wandering the Count's castle against Dracula's admonition, Harker encounters three vampire sisters, from whom he is rescued by Dracula. Harker soon realizes that Dracula himself is also a vampire. After the preparations are made, Dracula leaves Transylvania and abandons Harker to the sisters. Harker barely escapes from the castle with his life.\n" +
                    "\n" +
                    "Dracula boards a Russian ship, the Demeter, taking with him boxes of Transylvanian soil, which he requires in order to regain his strength. The ship weighs anchor at Varna and eventually runs aground on the shores of Whitby in north-east England. The captain's log narrates the gradual disappearance of the entire crew, until the captain alone remained, himself bound to the helm to maintain course. An animal resembling \"a large dog\" is seen leaping ashore. It is later learned that Dracula successfully purchased multiple estates under the alias 'Count De Ville' throughout London and devised to distribute the boxes to each of them utilizing transportation services as well as moving them himself. He does this to secure for himself lairs and the boxes of earth would be used as his graves which would grant safety and rest during times of feeding and replenishing his strength.\n" +
                    "\n" +
                    "Harker's fiancée, Mina Murray, is staying..."),
            new Horror("Frankenstein", R.drawable.frankenstein, "Victor begins by telling of his childhood. Born in Naples, Italy, into a wealthy Genevan family, Victor and his brothers, Ernest and William, all three being sons of Alphonse Frankenstein by the former Caroline Beaufort, are encouraged to seek a greater understanding of the world through chemistry. As a young boy, Victor is obsessed with studying outdated theories that focus on simulating natural wonders. When Victor is five years old, his parents adopt Elizabeth Lavenza, the orphaned daughter of an expropriated Italian nobleman, with whom Victor (allegedly) later falls in love. During this period, Victor's parents, Alphonse and Caroline, take in yet another orphan, Justine Moritz, who becomes William's nanny.\n" +
                    "\n" +
                    "Weeks before he leaves for the University of Ingolstadt in Germany, his mother dies of scarlet fever; Victor buries himself in his experiments to deal with the grief. At the university, he excels at chemistry and other sciences, soon developing a secret technique to impart life to non-living matter. Eventually, he undertakes the creation of a humanoid, but due to the difficulty in replicating the minute parts of the human body, Victor makes the Creature tall, about 8 feet (2.4 m) in height and proportionally large. Despite Victor's selecting its features as beautiful, upon animation the creature is instead hideous, with watery white eyes and yellow skin that barely conceals the muscles and blood vessels underneath. Repulsed by his work, Victor flees when it awakens. While wandering the streets, he meets his childhood friend, Henry Clerval, and takes Henry back to his apartment, fearful of Henry's reaction if he sees the monster. However, the Creature has escaped.\n" +
                    "\n" +
                    "Victor falls ill from..."),
            new Horror("Psycho", R.drawable.psycho, "Norman Bates, a middle-aged bachelor, is dominated by his mother, a mean-tempered, puritanical old woman who forbids him to have a life outside of her. They run a small motel together in the town of Fairvale, but business has floundered since the state relocated the highway. In the middle of a heated argument between them, a customer arrives, a young woman named Mary Crane.\n" +
                    "\n" +
                    "Mary is on the run after impulsively stealing $40,000 from a client of the real estate company where she works. She stole the money so her boyfriend, Sam Loomis, could pay off his debts and they could finally get married. Mary arrives at the Bates Motel after accidentally turning off the main highway. Exhausted, she accepts Bates' invitation to have dinner with him at his house, an invitation that sends Mrs. Bates into a jealous rage; she screams, \"I'll kill the bitch!\", which Mary then hears.\n" +
                    "\n" +
                    "During dinner, Mary gently..."),
            new Horror("The Exorcist", R.drawable.the_exorcist, "An elderly Jesuit priest named Father Lankester Merrin is leading an archaeological dig in northern Iraq and is studying ancient relics. After discovering a small statue of the demon Pazuzu (an actual ancient Assyrian demon), a series of omens alerts him to a pending confrontation with a powerful evil, which, unknown to the reader at this point, he has battled before in an exorcism in Africa.\n" +
                    "\n" +
                    "Meanwhile, in Georgetown, a young girl named Regan MacNeil is living with her famous mother, actress Chris MacNeil, who is in Georgetown filming a movie. As Chris finishes her work on the film, Regan begins to become inexplicably ill. After a gradual series of poltergeist-like disturbances in their rented house, for which Chris attempts to find rational explanations, Regan begins to rapidly undergo disturbing psychological and physical changes: she refuses to eat or sleep, becomes withdrawn and frenetic, and increasingly aggressive and violent. Chris initially mistakes Regan's behavior as a result of repressed anger over her parents' divorce and absent father.\n" +
                    "\n" +
                    "After several unsuccessful..."),
            new Horror("The Shining", R.drawable.the_shining, "Jack Torrance, his wife Wendy, and their five-year-old son Danny move into the hotel after Jack accepts the position as winter caretaker. Jack is an aspiring writer and recovering alcoholic with anger issues which, prior to the story, had caused him to accidentally break Danny's arm and lose his position as a teacher after assaulting a student. Jack hopes that the hotel's seclusion will help him reconnect with his family and give him the motivation needed to work on a play. Danny, unknown to his parents, possesses psychic abilities referred to as \"the shining\" that enable him to read minds and experience premonitions as well as clairvoyance. The Torrances arrive at the hotel on closing day and are given a tour by the manager. They meet Dick Hallorann, the chef, who also possesses similar abilities to Danny's and helps to explain them to him, giving Hallorann and Danny a special connection. The remaining staff and guests depart the hotel, leaving the Torrances alone in the hotel for the winter.\n" +
                    "\n" +
                    "As the Torrances settle in at the Overlook, Danny sees ghosts and frightening visions. Although Danny is close to his parents, he does not tell either of them about his visions because he senses that the care-taking job is important to his father and the family's future. Wendy considers leaving Jack at the Overlook to finish the job by himself; Danny refuses, thinking his father will be happier if they stayed. However, Danny soon realizes that his presence in the hotel makes the supernatural activity more powerful, turning echoes of past tragedies into dangerous threats. Apparitions take solid form and the garden's topiary animals come to life. The winter snowfall leaves the Torrances cut off from the outside world in the isolated hotel.\n" +
                    "\n" +
                    "The Overlook has difficulty..."),
            new Horror("The Silence of the Lambs", R.drawable.the_silence_the_lambs, "Clarice Starling, a young FBI trainee, is asked to carry out an errand by Jack Crawford, the head of the FBI division that draws up psychological profiles of serial killers. Starling is to present a questionnaire to the brilliant forensic psychiatrist and cannibalistic serial killer, Hannibal Lecter. Lecter is serving nine consecutive life sentences in a Maryland mental institution for a series of murders.\n" +
                    "\n" +
                    "Crawford's real intention, however, is to try to solicit Lecter's assistance in the hunt for a serial killer dubbed \"Buffalo Bill\", whose modus operandi involves kidnapping overweight women, starving them for up to two weeks, killing and skinning them, and dumping the remains in nearby rivers. The nickname was started by Kansas City Homicide, as a sick joke that \"he likes to skin his humps.\" Throughout the investigation, Starling periodically returns to Lecter in search of information, and the two form a strange relationship in which he offers her cryptic clues in return for information about her troubled and bleak childhood as an orphan.\n" +
                    "\n" +
                    "When Bill's sixth victim...")
    };

    private Horror(String name, int imageResourceId, String plot){
        this.name=name;
        this.imageResourceId= imageResourceId;
        this.plot = plot;
    }

    public String getName() {
        return name;
    }

    public int getImageResourceId() {
        return imageResourceId;
    }

    public String getPlot() {
        return plot;
    }
}
