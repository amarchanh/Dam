package com.hfad.bibliolectura;

import android.support.v4.content.ContextCompat;
import android.support.v7.app.ActionBar;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.Toolbar;
import android.widget.ImageView;
import android.widget.TextView;

public class ScienceFDetailActivity extends AppCompatActivity {

    public static final String EXTRA_SCIENCEF_ID ="sciencefId";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sciencef_detail);

        Toolbar toolbar = (Toolbar)findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        ActionBar actionBar = getSupportActionBar();
        actionBar.setDisplayHomeAsUpEnabled(true);

        int sciencefId = (Integer)getIntent().getExtras().get(EXTRA_SCIENCEF_ID);
        String sciencefName = ScienceF.sciences[sciencefId].getName();
        TextView textView = (TextView)findViewById(R.id.sciencef_text);
        textView.setText(sciencefName);
        int sciencefImage = ScienceF.sciences[sciencefId].getImageResourceId();
        ImageView imageView = (ImageView)findViewById(R.id.sciencef_image);
        imageView.setImageDrawable(ContextCompat.getDrawable(this, sciencefImage));
        imageView.setContentDescription(sciencefName);
        String sciencefPlot = ScienceF.sciences[sciencefId].getPlot();
        TextView textView2 = (TextView)findViewById(R.id.sciencef_plot);
        textView2.setText(sciencefPlot);
    }
}
