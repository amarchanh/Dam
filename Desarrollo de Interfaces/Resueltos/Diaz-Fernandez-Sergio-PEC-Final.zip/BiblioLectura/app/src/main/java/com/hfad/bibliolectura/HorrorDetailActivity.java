package com.hfad.bibliolectura;

import android.support.v4.content.ContextCompat;
import android.support.v7.app.ActionBar;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.Toolbar;
import android.widget.ImageView;
import android.widget.TextView;

public class HorrorDetailActivity extends AppCompatActivity {

    public static final String EXTRA_HORROR_ID ="horrorId";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_horror_detail);

        Toolbar toolbar = (Toolbar)findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        ActionBar actionBar = getSupportActionBar();
        actionBar.setDisplayHomeAsUpEnabled(true);

        int horrorId = (Integer)getIntent().getExtras().get(EXTRA_HORROR_ID);
        String horrorName = Horror.horrors[horrorId].getName();
        TextView textView = (TextView)findViewById(R.id.horror_text);
        textView.setText(horrorName);
        int horrorImage = Horror.horrors[horrorId].getImageResourceId();
        ImageView imageView = (ImageView)findViewById(R.id.horror_image);
        imageView.setImageDrawable(ContextCompat.getDrawable(this, horrorImage));
        imageView.setContentDescription(horrorName);
        String horrorPlot = Horror.horrors[horrorId].getPlot();
        TextView textView2 = (TextView)findViewById(R.id.horror_plot);
        textView2.setText(horrorPlot);
    }
}
