package com.example.toplevelactivity;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.ImageView;
import android.widget.TextView;

public class DetailDrinkActivity extends AppCompatActivity {

    public static final String EXTRA_DRINK_ID = "drinkId";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_detail_drink);

        //Creamos los conectores Java a los elementos visuales.
        ImageView imageView = (ImageView)findViewById(R.id.photo);
        TextView textView = (TextView)findViewById(R.id.name);
        TextView textView2 = (TextView)findViewById(R.id.description);

        //Acceder al elemento del array que queremos mostrar.
        int iD = (Integer)getIntent().getExtras().get(EXTRA_DRINK_ID);
        Drink drink = Drink.drinks[iD];

        //Rellenamos los elementos visuales
        textView.setText(drink.getName());
        textView2.setText(drink.getDescription());
        imageView.setImageResource(drink.getImageResourceId());
    }
}
