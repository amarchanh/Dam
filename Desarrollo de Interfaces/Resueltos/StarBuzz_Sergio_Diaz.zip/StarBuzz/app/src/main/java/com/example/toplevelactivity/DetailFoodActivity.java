package com.example.toplevelactivity;

import androidx.appcompat.app.AppCompatActivity;
import android.widget.ImageView;
import android.widget.TextView;
import android.os.Bundle;

public class DetailFoodActivity extends AppCompatActivity {

    public static final String EXTRA_FOOD_ID = "foodId";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_detail_food);

        //Creamos los conectores Java a los elementos visuales.
        ImageView imageView = (ImageView)findViewById(R.id.photo);
        TextView textView = (TextView)findViewById(R.id.name);
        TextView textView2 = (TextView)findViewById(R.id.description);

        //Acceder al elemento del array que queremos mostrar.
        int iD = (Integer)getIntent().getExtras().get(EXTRA_FOOD_ID);
        Food food = Food.foods[iD];

        //Rellenamos los elementos visuales
        textView.setText(food.getName());
        textView2.setText(food.getDescription());
        imageView.setImageResource(food.getImageResourceId());
    }
}
