package com.example.toplevelactivity;

public class Food {

    private String name;
    private String description;
    private int imageResourceId;

    private Food(String name, String description, int imageResourceId){
        this.name = name;
        this.description = description;
        this.imageResourceId = imageResourceId;
    }

    public static final Food[] foods={
            new Food("Pancakes", "Soft pancake with caramel", R.drawable.pancake),
            new Food("Waffle", "Delicious waffle with caramel or hot chocolate", R.drawable.waffle),
            new Food("Chocolate Muffin", "Big muffin with chocolate chips", R.drawable.chocolate_muffin)
    };

    public String getName() {
        return name;
    }

    public String getDescription() {
        return description;
    }

    public int getImageResourceId() {
        return imageResourceId;
    }

    public String toString(){
        return this.name;
    }
}
