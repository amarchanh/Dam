package com.example.starbuzzfragment;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;

public class CategoryActivity extends AppCompatActivity implements CategoryListFragment.CategoryListener {

    public static final String EXTRA_MAIN_ID = "main_id";
    int mainId;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_category);

        mainId = (int)getIntent().getExtras().get(EXTRA_MAIN_ID);

        CategoryListFragment frag = (CategoryListFragment)getSupportFragmentManager().findFragmentById(R.id.category_list_fragment);
        frag.setMainId(mainId);
    }

    @Override
    public void itemClicked(long id) {
        Intent intent = new Intent(this, DetailActivity.class);
        intent.putExtra(DetailActivity.EXTRA_CATEGORY_ID, (int) id);
        intent.putExtra(DetailActivity.EXTRA_MAIN_ID, mainId);
        startActivity(intent);
    }
}
