package com.example.starbuzzfragment;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class DetailActivity extends AppCompatActivity {

    public static final String EXTRA_CATEGORY_ID = "categoryId";
    public static final String EXTRA_MAIN_ID = "main_id";


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_detail);

        int categoryId = (int)getIntent().getExtras().get(EXTRA_CATEGORY_ID);
        int mainId = (int)getIntent().getExtras().get(EXTRA_MAIN_ID);
        DetailFragment frag = (DetailFragment)getSupportFragmentManager().findFragmentById(R.id.detail_fragment);
        frag.setCategoryId(categoryId);
        frag.setMainId(mainId);
    }
}
