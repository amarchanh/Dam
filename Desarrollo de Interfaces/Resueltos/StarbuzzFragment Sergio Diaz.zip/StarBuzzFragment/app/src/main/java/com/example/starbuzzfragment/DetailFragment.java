package com.example.starbuzzfragment;


import android.os.Bundle;

import androidx.fragment.app.Fragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;


/**
 * A simple {@link Fragment} subclass.
 */
public class DetailFragment extends Fragment {

    private long categoryId;
    private long mainId;
    public DetailFragment() {
        // Required empty public constructor
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        return inflater.inflate(R.layout.fragment_detail, container, false);
    }

    public void onStart(){
        super.onStart();
        /** Get view para saber a que interfaz gráfica (pantalla o todos los elementos juntos)*/
        View view = getView();
        if(view != null){
            TextView title = (TextView)view.findViewById(R.id.textName);
            TextView description = (TextView)view.findViewById(R.id.textDescription);
            ImageView image = (ImageView)view.findViewById(R.id.image);

            if(mainId == 0){
                Drink drink = Drink.drinks[(int)categoryId];

                title.setText(drink.getName());
                description.setText(drink.getDescription());
                image.setImageResource(drink.getImageResourceId());
            }
            else if(mainId == 1){
                Food food = Food.foods[(int)categoryId];

                title.setText(food.getName());
                description.setText(food.getDescription());
                image.setImageResource(food.getImageResourceId());

            }
            else if(mainId == 2){
                Store store = Store.stores[(int)categoryId];

                title.setText(store.getName());
                description.setText(store.getDescription());
                image.setImageResource(store.getImageResourceId());

            }

        }
    }

    public void setCategoryId(long categoryId) {
        this.categoryId = categoryId;
    }
    public void setMainId(long mainId) {
        this.mainId = mainId;
    }

}
