package com.example.starbuzzfragment;

public class Name {
    private String name;

    private Name(String name){
        this.name = name;
    }

    public static final Name[] names={
            new Name("Drinks"),
            new Name("Foods"),
            new Name("Stores")
    };

    public String getName() {
        return name;
    }

    public String toString(){
        return this.name;
    }
}
