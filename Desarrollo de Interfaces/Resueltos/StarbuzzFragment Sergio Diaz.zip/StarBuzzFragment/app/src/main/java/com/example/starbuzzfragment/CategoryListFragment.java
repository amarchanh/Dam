package com.example.starbuzzfragment;


import android.content.Context;
import android.os.Bundle;

import androidx.fragment.app.Fragment;
import androidx.fragment.app.ListFragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ListView;


/**
 * A simple {@link Fragment} subclass.
 */
public class CategoryListFragment extends ListFragment {

    static interface CategoryListener {
        void itemClicked(long id);
    }

    private CategoryListener listener;
    private long mainId;

    public CategoryListFragment() {
        // Required empty public constructor
    }

    public void onAttach(Context context) {
        super.onAttach(context);
        this.listener = (CategoryListener) context;
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {

        return super.onCreateView(inflater, container, savedInstanceState);
    }


    public void onStart(){
        super.onStart();
        LayoutInflater inflater = LayoutInflater.from(getActivity());
        if(this.mainId == 0){
            String drinks[] = new String[Drink.drinks.length];
            for (int i = 0; i < drinks.length; i++) {
                drinks[i] = Drink.drinks[i].getName();
            }
            ArrayAdapter<String> adapter = new ArrayAdapter<>(inflater.getContext(), android.R.layout.simple_list_item_1, drinks);
            setListAdapter(adapter);
        }

        else if(this.mainId == 1){
            String foods[] = new String[Food.foods.length];
            for (int i = 0; i < foods.length; i++) {
                foods[i] = Food.foods[i].getName();

            }
            ArrayAdapter<String> adapter = new ArrayAdapter<>(inflater.getContext(), android.R.layout.simple_list_item_1, foods);
            setListAdapter(adapter);
        }

        else if(this.mainId == 2){
            String stores[] = new String[Store.stores.length];
            for (int i = 0; i < stores.length; i++) {
                stores[i] = Store.stores[i].getName();
            }
            ArrayAdapter<String> adapter = new ArrayAdapter<>(inflater.getContext(), android.R.layout.simple_list_item_1, stores);
            setListAdapter(adapter);
        }


    }

    public void onListItemClick(ListView view, View itemView, int position, long id) {

        if (listener != null) {
            listener.itemClicked(id);
        }

    }

    public void setMainId(long mainId) {
        this.mainId = mainId;
    }

}
