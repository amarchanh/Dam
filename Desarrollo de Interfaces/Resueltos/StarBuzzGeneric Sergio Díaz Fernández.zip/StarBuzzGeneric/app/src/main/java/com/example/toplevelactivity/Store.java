package com.example.toplevelactivity;

public class Store {

    private String name;
    private String description;
    private int imageResourceId;

    private Store(String name, String description, int imageResourceId){
        this.name = name;
        this.description = description;
        this.imageResourceId = imageResourceId;
    }

    public static final Store[] stores={
            new Store("Madrid", "Tienda de Madrid", R.drawable.pancake),
            new Store("Barcelona", "Tienda de Barcelona", R.drawable.waffle),
            new Store("Valencia", "Tienda de Valencia", R.drawable.chocolate_muffin)
    };

    public String getName() {
        return name;
    }

    public String getDescription() {
        return description;
    }

    public int getImageResourceId() {
        return imageResourceId;
    }

    public String toString(){
        return this.name;
    }
}
