package com.example.toplevelactivity;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;

public class GenericCategoryActivity extends AppCompatActivity {
    static int iD;
    public static final String EXTRA_GENERIC_ID = "";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_generic_category);

        ListView listView = (ListView)findViewById(R.id.list_generic);

        iD = (Integer)getIntent().getExtras().get(EXTRA_GENERIC_ID);

        //Creamos el adaptador para rellenar el listView.
        if (iD == 0){
            ArrayAdapter<Drink> listAdapter1 = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, Drink.drinks);
            listView.setAdapter(listAdapter1);
        }
        if (iD == 1){
            ArrayAdapter<Food> listAdapter2 = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, Food.foods);
            listView.setAdapter(listAdapter2);
        }
        if (iD == 2){
           ArrayAdapter<Store> listAdapter3 = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, Store.stores);
           listView.setAdapter(listAdapter3);
        }


        //Creamos el escuchador para los elementos lista
        AdapterView.OnItemClickListener itemClickListener = new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> listView, View view, int position, long id) {

                if (iD == 2){
                    Intent intent = new Intent(GenericCategoryActivity.this, GPSDetailActivity.class);

                    /*intent.putExtra(GPSDetailActivity.EXTRA_DETAIL_ID, (int)id);
                    intent.putExtra(GPSDetailActivity.EXTRA_TYPE_ID, iD);*/

                    startActivity(intent);
                }
                else{
                    Intent intent = new Intent(GenericCategoryActivity.this, DetailGenericActivity.class);

                    intent.putExtra(DetailGenericActivity.EXTRA_DETAIL_ID, (int)id);
                    intent.putExtra(DetailGenericActivity.EXTRA_TYPE_ID, iD);

                    startActivity(intent);
                }

            }
        };

        listView.setOnItemClickListener(itemClickListener);
    }
}
