package com.example.toplevelactivity;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class GPSDetailActivity extends AppCompatActivity {

    /*public static final String EXTRA_DETAIL_ID = "genericId";
    public static final String EXTRA_TYPE_ID = "typeId";*/
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_gpsdetail);
    }
}
