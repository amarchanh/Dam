package com.example.toplevelactivity;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.ImageView;
import android.widget.TextView;

public class DetailGenericActivity extends AppCompatActivity {

    public static final String EXTRA_DETAIL_ID = "genericId";
    public static final String EXTRA_TYPE_ID = "typeId";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_generic_detail);

        //Creamos los conectores Java a los elementos visuales.
        ImageView imageView = (ImageView)findViewById(R.id.photo);
        TextView textView = (TextView)findViewById(R.id.name);
        TextView textView2 = (TextView)findViewById(R.id.description);

        //Acceder al elemento del array que queremos mostrar.
        int iD = (Integer)getIntent().getExtras().get(EXTRA_DETAIL_ID);
        int typeiD = (Integer)getIntent().getExtras().get(EXTRA_TYPE_ID);

        
        //Rellenamos los elementos visuales
        if (typeiD == 0){
            Drink drink = Drink.drinks[iD];
            textView.setText(drink.getName());
            textView2.setText(drink.getDescription());
            imageView.setImageResource(drink.getImageResourceId());
        }
        if (typeiD == 1){
            Food food = Food.foods[iD];
            textView.setText(food.getName());
            textView2.setText(food.getDescription());
            imageView.setImageResource(food.getImageResourceId());
        }


    }
}
