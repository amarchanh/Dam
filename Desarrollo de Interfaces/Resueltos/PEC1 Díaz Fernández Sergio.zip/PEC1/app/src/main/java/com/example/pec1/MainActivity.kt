package com.example.pec1

import androidx.appcompat.app.AppCompatActivity

import android.content.Intent
import android.os.Bundle
import android.util.Log
import android.view.View
import android.widget.EditText

class MainActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        Log.i("MainActivity", "Sergio Díaz Fernández")
    }

    fun onSendMessage(view: View) {

        val intent = Intent(this, Main2Activity::class)

        startActivity(intent)

    }
}
