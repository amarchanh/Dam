/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ejemplointerfaz;

/**
 *
 * @author Juan Carlos
 */
public class Impresora {
    
    private Imprimible obj;

    public Impresora(Imprimible obj) {
        this.obj = obj;
    }
    
    public void imprimirObjetoPorImpresora(){
        
        System.out.println(this.obj.imprimir());
    }
    
}
