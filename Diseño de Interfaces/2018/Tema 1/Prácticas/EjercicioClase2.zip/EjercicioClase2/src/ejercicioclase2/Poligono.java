/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ejercicioclase2;

/**
 *
 * @author Juan Carlos
 */
public abstract class Poligono {
    
    protected int numeroLados;

    public Poligono(int numeroLados) {
        this.numeroLados = numeroLados;
    }

    public int getNumeroLados() {
        return numeroLados;
    }
    
    @Override
    public String toString(){
        
        return "NumeroLados=" + numeroLados;
    }
    public abstract double area();
}

