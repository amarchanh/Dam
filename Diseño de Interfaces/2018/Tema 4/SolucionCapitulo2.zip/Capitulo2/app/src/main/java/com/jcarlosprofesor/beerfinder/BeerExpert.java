package com.jcarlosprofesor.beerfinder;

import java.util.ArrayList;

public class BeerExpert {

    //Creamos un ArrayList que va a contener las diferente marcas
    ArrayList<String>colors = new ArrayList<>();

    //En el constructor llenamos ese ArrayList con las marcas.
    public BeerExpert(){
        colors.add("Red Moose");
        colors.add("Jack Amber");
        colors.add("Jail Pale Ale");
        colors.add("Gout Stout");
    }

    //Metodo que devuelve la marca que equivale al color seleccionado por el
    //usuario en el spinner
    public String getColors(String color) {

        String brand="";
        switch (color) {
            case ("light"): {
                brand=colors.get(0);
                break;
            }
            case ("amber"): {
                brand=colors.get(1);
                break;
            }
            case ("brown"): {
                brand=colors.get(2);
                break;
            }
            case ("dark"): {
                brand=colors.get(3);
                break;
            }
        }
        return brand;
    }
}
