package com.jcarlosprofesor.beerfinder;

import android.app.Activity;
import android.os.Bundle;
import android.view.View;
import android.widget.Spinner;
import android.widget.TextView;

public class BeerFindActivity extends Activity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_beer_find);
    }

    //Metodo propio que se llama desde el boton

    public void onFindBeer(View view){

        //Creamos un objeto de la clase auxiliar
        BeerExpert beerExpert = new BeerExpert();
        //Creamos y capturamos el objeto TextView de la pantalla para poder trabajar con el.
        TextView textView = (TextView)findViewById(R.id.beerRecommended);
        //Hacemos lo mismo para el objeto Spinner
        Spinner spinner =(Spinner)findViewById(R.id.colors);
        //Guardar en un String la opcion seleccionada por el usuario
        String colorSelected = spinner.getSelectedItem().toString();
        //Sustituir el texto mostrado por el objeto TextView
        //por el contenido que devuelve el objeto de la clase auxiliar
        //que hemos creado
        textView.setText(beerExpert.getColors(colorSelected));



    }
}
