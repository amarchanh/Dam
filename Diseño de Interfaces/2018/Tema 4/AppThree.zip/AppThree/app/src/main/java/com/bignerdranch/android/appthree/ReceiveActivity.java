package com.bignerdranch.android.appthree;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.widget.TextView;

public class ReceiveActivity extends Activity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_receive);

        TextView textView = (TextView)findViewById(R.id.receive_message);
        Intent intent = getIntent();
        String mensaje_recibido = intent.getStringExtra("mensaje");
        textView.setText(mensaje_recibido);
    }
}
